# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

## ---(Mon Nov 27 20:13:01 2023)---
runfile('C:/Users/Asus/test-assignment-piterjhonm/assignment.py', wdir='C:/Users/Asus/test-assignment-piterjhonm')

## ---(Mon Nov 27 20:27:32 2023)---
runfile('C:/Users/Asus/test-assignment-piterjhonm/assignment.py', wdir='C:/Users/Asus/test-assignment-piterjhonm')

## ---(Mon Dec  4 22:15:45 2023)---
runfile('C:/Users/Asus/exercise-1-piterjhonm/exercise_1.py', wdir='C:/Users/Asus/exercise-1-piterjhonm')

## ---(Thu Dec  7 20:37:06 2023)---
runfile('C:/Users/Asus/exercise-2-piterjhonm/exercise_2.py', wdir='C:/Users/Asus/exercise-2-piterjhonm')

## ---(Thu Dec  7 22:00:34 2023)---
runfile('C:/Users/Asus/exercise-2-piterjhonm/exercise_2.py', wdir='C:/Users/Asus/exercise-2-piterjhonm')

## ---(Sun Dec 17 20:20:02 2023)---
runfile('C:/Users/Asus/exercise-4-piterjhonm/exercise_4.py', wdir='C:/Users/Asus/exercise-4-piterjhonm')

## ---(Sun Dec 17 22:15:26 2023)---
runfile('C:/Users/Asus/exercise-4-piterjhonm/exercise_4.py', wdir='C:/Users/Asus/exercise-4-piterjhonm')

## ---(Sun Dec 17 23:50:04 2023)---
runfile('C:/Users/Asus/exercise-4-piterjhonm/exercise_4.py', wdir='C:/Users/Asus/exercise-4-piterjhonm')

## ---(Sun Dec 17 23:51:48 2023)---
runfile('C:/Users/Asus/exercise-4-piterjhonm/exercise_4.py', wdir='C:/Users/Asus/exercise-4-piterjhonm')

## ---(Sun Dec 17 23:55:57 2023)---
runfile('C:/Users/Asus/exercise-4-piterjhonm/exercise_4.py', wdir='C:/Users/Asus/exercise-4-piterjhonm')

## ---(Tue Jan  2 15:13:23 2024)---
runfile('C:/Users/Asus/untitled0.py', wdir='C:/Users/Asus')
runfile('C:/Users/Asus/UAS.py', wdir='C:/Users/Asus')

## ---(Tue Jan  2 17:14:53 2024)---
runfile('C:/Users/Asus/JhonPiterM-4212331009/UAS.py', wdir='C:/Users/Asus/JhonPiterM-4212331009')
2
3
1
runfile('C:/Users/Asus/JhonPiterM-4212331009/UAS.py', wdir='C:/Users/Asus/JhonPiterM-4212331009')

## ---(Tue Jan  2 17:32:14 2024)---
runfile('C:/Users/Asus/JhonPiterM-4212331009/UAS.py', wdir='C:/Users/Asus/JhonPiterM-4212331009')

## ---(Tue Jan  2 17:40:40 2024)---
runfile('C:/Users/Asus/JhonPiterM-4212331009/UAS.py', wdir='C:/Users/Asus/JhonPiterM-4212331009')

## ---(Tue Jan  2 17:41:44 2024)---
runfile('C:/Users/Asus/JhonPiterM-4212331009/UAS.py', wdir='C:/Users/Asus/JhonPiterM-4212331009')
3
2
runfile('C:/Users/Asus/JhonPiterM-4212331009/UAS.py', wdir='C:/Users/Asus/JhonPiterM-4212331009')

## ---(Tue Jan  2 17:50:28 2024)---
runfile('C:/Users/Asus/JhonPiterM-4212331009/UAS.py', wdir='C:/Users/Asus/JhonPiterM-4212331009')

## ---(Tue Jan  2 19:08:01 2024)---
runfile('C:/Users/Asus/JhonPiterM-4212331009/UAS.py', wdir='C:/Users/Asus/JhonPiterM-4212331009')

## ---(Wed Jan  3 19:55:49 2024)---
runfile('C:/Users/Asus/JhonPiterM-4212331009/UAS.py', wdir='C:/Users/Asus/JhonPiterM-4212331009')

## ---(Wed Jan 10 17:44:19 2024)---
runfile('C:/Users/Asus/JhonPiterM-4212331009/UAS.py', wdir='C:/Users/Asus/JhonPiterM-4212331009')

## ---(Thu Jan 11 22:20:19 2024)---
runfile('C:/Users/Asus/JhonPiterM-4212331009/UAS.py', wdir='C:/Users/Asus/JhonPiterM-4212331009')

## ---(Fri Jan 12 01:37:02 2024)---
runfile('C:/Users/Asus/JhonPiterM-4212331009/UAS.py', wdir='C:/Users/Asus/JhonPiterM-4212331009')

## ---(Fri Jan 12 01:42:21 2024)---
runfile('C:/Users/Asus/4212331009-JhonPiterM/test.py', wdir='C:/Users/Asus/4212331009-JhonPiterM')

## ---(Fri Jan 12 02:01:46 2024)---
runfile('C:/Users/Asus/4212331009-JhonPiterM/untitled0.py', wdir='C:/Users/Asus/4212331009-JhonPiterM')

## ---(Fri Jan 12 02:19:50 2024)---
runfile('C:/Users/Asus/4212331009-JhonPiterM/test2.py', wdir='C:/Users/Asus/4212331009-JhonPiterM')

## ---(Fri Jan 12 02:39:50 2024)---
runfile('C:/Users/Asus/4212331009-JhonPiterM/test4.py', wdir='C:/Users/Asus/4212331009-JhonPiterM')
runfile('C:/Users/Asus/4212331009-JhonPiterM/test2.py', wdir='C:/Users/Asus/4212331009-JhonPiterM')

## ---(Fri Jan 12 02:56:51 2024)---
runfile('C:/Users/Asus/4212331009-JhonPiterM/test2.py', wdir='C:/Users/Asus/4212331009-JhonPiterM')
runfile('C:/Users/Asus/.spyder-py3/temp.py', wdir='C:/Users/Asus/.spyder-py3')